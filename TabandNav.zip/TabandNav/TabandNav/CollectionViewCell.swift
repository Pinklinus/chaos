//
//  CollectionViewCell.swift
//  TabandNav
//
//  Created by Helen Hall on 7/21/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var cellContentView: UIView!
    @IBOutlet weak var imageCell: UIImageView!
    
}
